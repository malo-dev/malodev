import { View, Text } from 'react-native'

export default function Favorie() {
  return (
    <View style={{ flex:1, justifyContent:'center', alignItems:'center' }}>
      <Text>Market Screen</Text>
    </View>
  )
}