import { View, Text } from 'react-native'

export default function Search() {
  return (
    <View style={{ flex:1, justifyContent:'center', alignItems:'center' }}>
      <Text>Market Screen</Text>
    </View>
  )
}