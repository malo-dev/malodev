// app/index.tsx
import { Text } from "react-native"
export default function HomeScreen() {
  return <Text>Home</Text>
}